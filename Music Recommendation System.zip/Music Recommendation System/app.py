from flask import Flask, request, jsonify, render_template
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import StandardScaler

# Load datasets and compute similarity (same as before)
train_df = pd.read_csv('C:/Users/surya/Desktop/pyton/Music Recommendation System/ClassicHit.csv')
audio_features = ['Tempo', 'Energy', 'Danceability', 'Acousticness', 'Valence']

scaler = StandardScaler()
train_df[audio_features] = scaler.fit_transform(train_df[audio_features])
train_cosine_sim = cosine_similarity(train_df[audio_features])
track_to_index_train = pd.Series(train_df.index, index=train_df['Track']).to_dict()

app = Flask(__name__)

def get_recommendations(track_name, n_recommendations=5):
    if track_name in track_to_index_train:
        track_idx = track_to_index_train[track_name]
        sim_scores = list(enumerate(train_cosine_sim[track_idx]))
        sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
        sim_scores = sim_scores[1:n_recommendations + 1]
        track_indices = [i[0] for i in sim_scores]
        return train_df['Track'].iloc[track_indices].tolist()
    else:
        return {"error": "Track not found."}

@app.route('/recommend', methods=['GET'])
def recommend():
    track_name = request.args.get('track')
    if not track_name:
        return jsonify({"error": "No track name provided."}), 400
    recommendations = get_recommendations(track_name)
    if "error" in recommendations:
        return jsonify(recommendations), 404
    return jsonify({"recommendations": recommendations})

@app.route('/', methods=['GET'])
def home():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
